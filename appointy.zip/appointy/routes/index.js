var express = require('express');
var router = express.Router();

const Articles = require("../database/model/article");

router.get('/', async (req, res)=>{
	try{
		let { recordToSkip, limitForRecord } = req.query;

		recordToSkip = Number(recordToSkip);
		limitForRecord = Number(limitForRecord);

		let articleData = await Articles.find({}).skip(recordToSkip).limit(limitForRecord);

		if (articleData.length == 0) {
			throw "NO DATA FOUND";
		}

		return res.json({data: articleData});

	}catch(error){
		errorHandler(error, res);
	}
});

router.post('/', async (req, res)=>{
	try{
		const { title, subtitle, content } = req.body;

		let articleData = await Articles.create({
			title, 
			subtitle,
			content
		});

		return res.json({msg: "ARTICLE SAVED SUCCESSFULLY", data: articleData});
	}catch(error){
		return errorHandler(error, res);
	}
});


router.get('/:articleID', async (req, res)=>{
	try{
		let articleData = await Articles.findById(req.params.articleID);

		if (!articleData) throw "ARTICLE NOT FOUND";

		return res.json({data: articleData});
	}catch(error){
		return errorHandler(error, res);
	}
});

router.get("/search", async (req, res)=>{
	try{
		const { q } = req.query;

		console.log(req.query);
		let articleData = await Articles.find({$or:[{title:{ '$regex': q}}, 
		{subtitle:{"$regex":q}},{content:{"$regex":q}}]})//.collation(  { locale: 'en', strength: 2 });

		if (!articleData) throw "NO DATA FOUND";

		return res.json({data: articleData});

	}catch(error){
		return errorHandler(error, res);
	}
});

function errorHandler (error, res){
	return res.status(500).json({msg: error});
}

module.exports = router;
