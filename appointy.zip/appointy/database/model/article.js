// Schema for details about the user
let mongoose    = require('mongoose');

let articleSchema = new mongoose.Schema({
    title: {
        type: String,
        trim: true,
        uppercase: true,
        default: null,
        require: true
    }, 
    subtitle: {
        type: String,
        default: null,
        trim: true,
        uppercase: true,
    }, 
    content: {
        type: String,
        trim: true,
        uppercase: true,
        default: null,
    }
},
    //time when user was registered to our platform
    {
        timestamps:true
    }
)

module.exports =  mongoose.model('appointy_articles', articleSchema);
