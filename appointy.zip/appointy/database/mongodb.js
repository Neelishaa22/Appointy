const mongoose = require('mongoose');

//database url picker
const DB_PARA = { 
    useUnifiedTopology: true,  
    useNewUrlParser: true, 
    useFindAndModify: false,
    useCreateIndex: true 
};

function dbConnect() {
    const DB_URI = process.env.MONGODB_URL || "mongodb://localhost:27017/appointy";

    return mongoose.connect(DB_URI, DB_PARA, err => {
        if (err) console.error.bind('connection error: ', err);
        console.log("Connected to MongoDB");
    });
}

function close() {
    console.log("Connection close");
    return mongoose.disconnect();
}

module.exports = { dbConnect, close };